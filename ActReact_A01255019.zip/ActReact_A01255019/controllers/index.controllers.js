export const raiz = (req, res) => res.send("hola mundo! desde mi api");
export const marco = (req, res) => res.send("Polo");
export const ping = (req, res) => res.send("Pong");
